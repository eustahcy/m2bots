Deps:
pkg install cmake

How to compile:
cd DevIL/DevIL
cmake CMakeLists.txt
make
(or make install)

How to clean up:
cd DevIL/DevIL
rm -f CMakeCache.txt
make clean

Source: https://github.com/martysama0134/libdevil-patched

----------
2025.03.31.
Modified DevIL/DevIL/src-IL/src/il_manip.cpp, removed 'register' storage class specifier (line 40-47).
Register is deprecated, safe to remove, otherwise you cannot recompile it.
